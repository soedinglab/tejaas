import numpy as np
def rscore(GT, GX, sigmabeta2, sigmax2):
	nsnps = GT.shape[0]
	nsamples = GT.shape[1]
	ngenes = GX.shape[0]
	Rscore = [None for i in range(nsnps)]
	pvals_ultra = [None for i in range(nsnps)]
	Yt = GX.T # shape N x G
	U, S, Vt = np.linalg.svd(Yt, full_matrices=False)
	S2 = np.square(S)
	for i in range(nsnps):
		S2mod = S2 + sigmax2[i] / sigmabeta2
		W = np.dot(U, np.dot(np.diag(S2 / S2mod), U.T))
		## replace this with a vector array (pythonic version)
		Rscore[i] = np.sum(np.square(np.dot(U.T, GT[i,:])) * S2 / S2mod)
		#pvals_ultra[i] = regnull.ultra_new_pvals(GT,np.array([Rscore[i]]),W,sigmabeta2, sigmax2[i])[0]
	Rscore = np.array(Rscore)
	#pvals_ultra = np.array(pvals_ultra)

	return Rscore, S, W, S2/S2mod
