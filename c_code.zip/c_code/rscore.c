#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "svd.h"
#include "test.h"
float ** transpose(float ** mat, int m, int n);
float ** memalloc(float ** mat, int m, int n);
void     mat_square(float ** mat, int m, int n);
void	 arr_square(float * arr, int n);
float ** matmult(float ** a, float ** b, int m, int n, int p);
float    mean(float * values, int n);
float    var(float * values, int n);
float *  mat_var( float ** mat, int m, int n);
float *  mat_mean( float ** mat, int m, int n);
float *  arr_add(float * a, float *b, int n);
float *  arr_add_val(float * a, float val, int n);
float *  arr_div(float * a, float *b, int n);
float    arr_dot(float * a, float *b, int n);
float *  arr_mult(float * a, float *b, int n);
float **  mat_sum(float ** a, float ** b, int m, int n);

int      min(int a, int b);
int      max(int a, int b);

float* rscore_maf(float ** gt, float ** gx, float sigmabeta2, int ngenes, int nsnps, int nsamples ){
	float ** U 	= transpose(transpose(gx, ngenes, nsamples), nsamples, ngenes);
	float ** V;
	V = memalloc(V, ngenes, ngenes);
	float *S  	= (float *) malloc (nsamples * sizeof(float));
	dsvd(U, ngenes,  nsamples, S, V);
	float * s2 	= S;
	arr_square(s2, nsamples);
	float * s2mod 	= (float *) malloc (nsamples * sizeof(float));
	memcpy(s2mod, s2, sizeof(float)*nsamples);
	float sigmax2 = 1;
	float fact 	=  sigmax2 / sigmabeta2;
	float * s2term_deno = arr_add_val(s2, fact, nsamples);
	float * s2term 	= arr_div(s2, s2term_deno, nsamples);
	float ** Q;
	V = transpose(V,nsamples, nsamples);
	Q = memalloc(Q, nsamples, nsamples);
	for( int i=0 ; i<nsamples ;i++ ){
		float ** ukukT = matmult( transpose(V + i, 1, nsamples),V+i, nsamples, 1, nsamples);
		for(int j = 0; j<nsamples; j++){
			for(int k =0; k<nsamples;k++){
				ukukT[j][k] = ukukT[j][k]*s2term[i];

			}
		}
		Q = mat_sum(Q,ukukT,nsamples, nsamples);
	}
	float * Rscore = (float *)calloc(nsnps , sizeof(float));
	float ** gt_V = matmult(gt, transpose(V, nsamples, nsamples), nsnps, nsamples, nsamples);
	mat_square(gt_V, nsnps, nsamples);
	for(int i=0; i< nsnps; i++){
		for(int j=0;j<nsamples;j++){
			Rscore[i] += gt_V[i][j] * s2term[j];
		}
	}
	return Rscore;
}

float* rscore_perm(float ** gt, float ** gx, float * sigmabeta2, int ngenes, int nsnps, int nsamples ){
	float ** U      = transpose(transpose(gx, ngenes, nsamples), nsamples, ngenes);
        float ** V;
        V = memalloc(V, ngenes, ngenes);
        float *S        = (float *) malloc (nsamples * sizeof(float));
        dsvd(U, ngenes,  nsamples, S, V);
        float * s2      = S;
        arr_square(s2, nsamples);
        float * s2mod   = (float *) malloc (nsamples * sizeof(float));
        memcpy(s2mod, s2, sizeof(float)*nsamples);
        float * sigmax2        = mat_var(gt, nsnps, nsamples);
        float * Rscore = (float *)calloc(nsnps , sizeof(float));
        V = transpose(V,nsamples, nsamples);
        for (int i=0; i<nsnps; i++){
		float fact      =  sigmax2[i] / sigmabeta2[i];
        	float * s2term_deno = arr_add_val(s2, fact, nsamples);
        	float * s2term  = arr_div(s2, s2term_deno, nsamples);
		float ** Q;
        	Q = memalloc(Q, nsamples, nsamples);
        	for( int i=0 ; i<nsamples ;i++ ){
                	float ** ukukT = matmult( transpose(V + i, 1, nsamples),V+i, nsamples, 1, nsamples);
			for(int j = 0; j<nsamples; j++){
                        	for(int k =0; k<nsamples;k++){
                                	ukukT[j][k] = ukukT[j][k]*s2term[i];

                        	}
                	}
                	Q = mat_sum(Q,ukukT,nsamples, nsamples);
        	}	
		print(Q, nsamples, nsamples);
		printf("\n");	
        	float ** gt_V = matmult(gt, transpose(V, nsamples, nsamples), nsnps, nsamples, nsamples);
        	mat_square(gt_V, nsnps, nsamples);
                for(int j=0;j<nsamples;j++){
                        	Rscore[i] += gt_V[i][j] * s2term[j];
                }
        	
	}
	return Rscore;
}

int main(){
	float ** a;
	float ** b;
	float * sigmabeta2 = (float *)calloc(10, sizeof(float));
	a = memalloc(a, 5, 3);   //i = 5, n = 3, g = 5
        b = memalloc(b, 10, 3);
	for(int i=0; i < 5; i++){
                a[i][0] = i + 1;
                a[i][1] = i + 2;
                a[i][2] = i + 3;
        }
        for(int i=0; i < 10; i++){
                b[i][0] = i + 1;
                b[i][1] = i + 2;
                b[i][2] = i + 3;
                sigmabeta2[i] = 0.0016;
        }
	float * Rscore = rscore_maf(b, a, sigmabeta2[0], 5, 10, 3);
	print(&Rscore, 1, 10);
	return 0;
}

float ** mat_sum(float** a, float **b, int m, int n){
	float ** sum;
	sum = memalloc(sum, m, n);
	for(int i = 0; i< m; i++){
		for(int j=0;j< n; j++){
			*(*(sum + i) + j) = a[i][j] + b[i][j];
		}
	}
	return sum;
}

int min(int a, int b){
	if(a < b) return a;
	else return b;
}

int max(int a, int b){
	if(a > b) return a;
	else return b;
}

float ** transpose(float ** mat, int m, int n){
	float ** tr = (float **)malloc(n * sizeof(float *));
	for(int i = 0; i < n ; i ++){
		*(tr + i) = (float *)malloc(m * sizeof(float));
		for (int j = 0; j < m; j ++){
			*(*(tr + i) + j) = mat[j][i];
		}
	}

	return tr;
}

float ** memalloc(float ** mat, int m, int n){
	mat = (float **)calloc(m, sizeof(float *));                                              
        for(int i = 0; i < m ; i ++){                                                                     
                *(mat + i) = (float *)calloc(n, sizeof(float));                                                                                                                                    
        }
	return mat;
}

void mat_square(float ** mat, int m, int n){
	for(int i=0; i < m; i++){
		for(int j=0; j < n; j++){
			*(*(mat + i) + j) = mat[i][j] * mat[i][j];			
		}
      	}
	return;
}

void arr_square(float * arr, int n){
	for( int j =0; j < n; j++) {
		*(arr + j) = arr[j] * arr[j];
	}
	return;
}

float arr_dot(float *a, float *b, int n){
	float dot = 0;
        for (int i = 0; i< n; i++){
                dot += a[i] * b[i];
        }
        return dot;
}

float ** matmult(float ** a, float ** b, int m, int n, int p){
	float **result = (float **)malloc (m * sizeof (float *));
	// if (!result) throw error

	register int i=0, j=0, k=0;
	for (i = 0; i < m; i++)
	{
        /* calloc initializes all to '0' */
        result[i] = (float *)calloc (p, sizeof (float));
        // if (!result[i]) throw error
	}

	for (i = 0; i < m; i++)
	{
        	for (j = 0; j < p; j++)
        	{
            		for (k = 0; k < n; k++)
            		{
                	result [i][j] += a [i][k] * b [k][j];
            	}
        }
    }

    return result;

}

/**
 * calculate the mean of the provided list values, containing n values.
 */
float mean(float * values, int n)
{
	float sum = 0;
	for (int i = 0; i < n; i++)
	{
        	sum += values[i];
    	}
   	 return sum / n;
}


/**
 * calculate the variance of the provided list values, containing n values.
 */

float var(float * values, int n)
{
    	float valuesMean = mean(values, n);
    	float sum = 0;
    	for (int i = 0; i < n; i++)
    	{
        	sum += (values[i] - valuesMean) * (values[i] - valuesMean);
    	}
    	return sum / n;
}
float* mat_var(float ** mat, int m ,int n){
	float * vars = (float *)malloc(m * sizeof(float));
	for (int i = 0; i< m; i++){
		vars[i] = var(*(mat + i), n);
	}
	return vars;
} 

float* mat_mean(float ** mat, int m , int n){
        float * means = (float *)malloc(m * sizeof(float));
        for (int i = 0; i< m; i++){
                means[i] = mean(*(mat + i), n);
        }
        return means;
}

float* arr_add(float * a, float * b, int n){
	float * sum = (float *)malloc(n * sizeof(float));
        for (int i = 0; i< n; i++){
                sum[i] = a[i] + b[i];
        }
        return sum;

}

float* arr_add_val(float * a, float val, int n){
        float * sum = (float *)malloc(n * sizeof(float));
        for (int i = 0; i< n; i++){
                sum[i] = a[i] + val;
        }
        return sum;

}


float* arr_div(float * a, float * b, int n){
        float * div = (float *)malloc(n * sizeof(float));
        for (int i = 0; i< n; i++){
                div[i] = a[i] / b[i];
        }
        return div;

}

float* arr_mult(float * a, float * b, int n){
        float * mul = (float *)malloc(n * sizeof(float));
        for (int i = 0; i< n; i++){
                mul[i] = a[i] * b[i];
        }
        return mul;

}

