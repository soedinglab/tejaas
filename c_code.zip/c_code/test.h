#include <stdio.h>
#include <stdlib.h>
void print( float ** v, int m, int n){
	for(int i =0; i <  m; i++){
		for(int j = 0; j < n; j++){
			printf("%f ",*(*(v + i) + j));
		}
		printf("\n");
	}
}

/*int main(){
	float ** a = (float **)malloc(5 * sizeof(float *));
	for(int i=0; i < 3; i++){
		*(a + i)  = (float *)malloc(3 * sizeof(float));
		a[i][0] = i + 1;
		a[i][1] = i + 2;
		a[i][2] = i + 3;
		printf("%f %f %f \n", a[i][0], a[i][1], a[i][2]);
	}
	int m = 5;
	int n = 3;
	float * w = (float*)malloc(m * sizeof(float));
	float ** v = (float **) malloc(n * sizeof(float *));
	for(int i=0; i < n; i++){
                *(v + i)  = (float *)malloc(n * sizeof(float));
        }
	printf("working");
	dsvd(a, m, n, w, v);
	print(a, m, n);
	print(&w, 1, n);
	return 0;
}*/
